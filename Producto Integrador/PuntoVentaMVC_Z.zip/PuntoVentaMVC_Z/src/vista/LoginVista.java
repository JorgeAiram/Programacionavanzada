package vista;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginVista extends JFrame {

    private static final long serialVersionUID = 1L;

    private JTextField txtUsuario;

    private JPasswordField txtPassword;

    private JButton btnLogin;

    private static final Color COLOR_AZUL =
        new Color(37, 99, 235);

    private static final Color COLOR_AZUL_OSCURO =
        new Color(15, 23, 42);

    private static final Color COLOR_AZUL_CLARO =
        new Color(96, 165, 250);

    private static final Color COLOR_BORDE =
        new Color(203, 213, 225);

    private static final Color COLOR_GRIS =
        new Color(100, 116, 139);

    public LoginVista() {

        setTitle("Punto de Venta - Acceso");

        setSize(900, 540);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
            JFrame.EXIT_ON_CLOSE
        );

        setResizable(false);

        getContentPane().setLayout(null);



        // Panel izquierdo
        JPanel panelIzquierdo = new JPanel() {

            private static final long
                serialVersionUID = 1L;

            @Override
            protected void paintComponent(
                Graphics g
            ) {

                super.paintComponent(g);

                Graphics2D g2 =
                    (Graphics2D) g;

                g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
                );

                // Circulo decorativo grande
                g2.setColor(
                    new Color(
                        255, 255, 255, 18
                    )
                );

                g2.fillOval(-80, -80, 380, 380);

                // Circulo decorativo pequeño
                g2.setColor(
                    new Color(
                        255, 255, 255, 12
                    )
                );

                g2.fillOval(
                    100, 300, 320, 320
                );
            }
        };

        panelIzquierdo.setBackground(COLOR_AZUL);

        panelIzquierdo.setBounds(
            0, 0, 420, 540
        );

        panelIzquierdo.setLayout(null);

        getContentPane().add(panelIzquierdo);



        // Bloque superior izquierdo
        JPanel bloqueTop = new JPanel();

        bloqueTop.setBackground(
            new Color(255, 255, 255, 30)
        );

        bloqueTop.setBounds(40, 40, 6, 60);

        bloqueTop.setLayout(null);

        panelIzquierdo.add(bloqueTop);



        JLabel lblSistema = new JLabel(
            "SISTEMA"
        );

        lblSistema.setForeground(
            COLOR_AZUL_CLARO
        );

        lblSistema.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        lblSistema.setBounds(58, 40, 200, 22);

        panelIzquierdo.add(lblSistema);



        JLabel lblNombre = new JLabel(
            "Punto de Venta"
        );

        lblNombre.setForeground(Color.WHITE);

        lblNombre.setFont(
            new Font("Arial Black", Font.BOLD, 28)
        );

        lblNombre.setBounds(55, 62, 320, 40);

        panelIzquierdo.add(lblNombre);



        // Separador
        JPanel sep = new JPanel();

        sep.setBackground(
            new Color(255, 255, 255, 60)
        );

        sep.setBounds(55, 115, 160, 2);

        panelIzquierdo.add(sep);



        JLabel lblDesc = new JLabel(
            "Gestion de ventas e inventario"
        );

        lblDesc.setForeground(
            new Color(191, 219, 254)
        );

        lblDesc.setFont(
            new Font("Arial", Font.PLAIN, 14)
        );

        lblDesc.setBounds(55, 130, 310, 28);

        panelIzquierdo.add(lblDesc);



        // Version
        JLabel lblVersion = new JLabel(
            "v1.0  -  2026"
        );

        lblVersion.setForeground(
            new Color(148, 163, 184)
        );

        lblVersion.setFont(
            new Font("Arial", Font.PLAIN, 11)
        );

        lblVersion.setBounds(55, 490, 200, 20);

        panelIzquierdo.add(lblVersion);



        // Panel derecho
        JPanel panelDerecho = new JPanel();

        panelDerecho.setBackground(Color.WHITE);

        panelDerecho.setBounds(
            420, 0, 480, 540
        );

        panelDerecho.setLayout(null);

        getContentPane().add(panelDerecho);



        JLabel lblBienvenido = new JLabel(
            "Bienvenido"
        );

        lblBienvenido.setFont(
            new Font("Arial", Font.PLAIN, 15)
        );

        lblBienvenido.setForeground(COLOR_GRIS);

        lblBienvenido.setBounds(90, 80, 300, 25);

        panelDerecho.add(lblBienvenido);



        JLabel lblLogin = new JLabel(
            "Iniciar Sesion"
        );

        lblLogin.setFont(
            new Font("Arial Black", Font.BOLD, 26)
        );

        lblLogin.setForeground(COLOR_AZUL_OSCURO);

        lblLogin.setBounds(90, 105, 300, 38);

        panelDerecho.add(lblLogin);



        JPanel sepD = new JPanel();

        sepD.setBackground(COLOR_AZUL);

        sepD.setBounds(90, 150, 50, 3);

        panelDerecho.add(sepD);



        // Campo usuario
        JLabel lblUsuario = new JLabel(
            "Usuario"
        );

        lblUsuario.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        lblUsuario.setForeground(COLOR_AZUL_OSCURO);

        lblUsuario.setBounds(90, 185, 200, 22);

        panelDerecho.add(lblUsuario);



        txtUsuario = new JTextField();

        txtUsuario.setBounds(90, 210, 300, 44);

        txtUsuario.setFont(
            new Font("Arial", Font.PLAIN, 15)
        );

        txtUsuario.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    COLOR_BORDE, 1
                ),
                BorderFactory.createEmptyBorder(
                    5, 12, 5, 12
                )
            )
        );

        txtUsuario.setBackground(
            new Color(248, 250, 252)
        );

        panelDerecho.add(txtUsuario);



        // Campo password
        JLabel lblPassword = new JLabel(
            "Contrasena"
        );

        lblPassword.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        lblPassword.setForeground(COLOR_AZUL_OSCURO);

        lblPassword.setBounds(90, 278, 200, 22);

        panelDerecho.add(lblPassword);



        txtPassword = new JPasswordField();

        txtPassword.setBounds(90, 303, 300, 44);

        txtPassword.setFont(
            new Font("Arial", Font.PLAIN, 15)
        );

        txtPassword.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    COLOR_BORDE, 1
                ),
                BorderFactory.createEmptyBorder(
                    5, 12, 5, 12
                )
            )
        );

        txtPassword.setBackground(
            new Color(248, 250, 252)
        );

        panelDerecho.add(txtPassword);



        // Boton login
        btnLogin = new JButton("Ingresar al sistema");

        btnLogin.setBounds(90, 385, 300, 48);

        btnLogin.setFont(
            new Font("Arial", Font.BOLD, 15)
        );

        btnLogin.setForeground(Color.WHITE);

        btnLogin.setBackground(COLOR_AZUL);

        btnLogin.setFocusPainted(false);

        btnLogin.setBorderPainted(false);

        btnLogin.setCursor(
            new java.awt.Cursor(
                java.awt.Cursor.HAND_CURSOR
            )
        );

        panelDerecho.add(btnLogin);




    }

    public JTextField getTxtUsuario() {
        return txtUsuario;
    }

    public JPasswordField getTxtPassword() {
        return txtPassword;
    }

    public JButton getBtnLogin() {
        return btnLogin;
    }
}