package vista;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class AlmacenVista extends JPanel {

    private static final long serialVersionUID = 1L;
    private JTextField txtIdProducto;

    private JTextField txtCantidad;

    private JButton btnAgregarStock;

    private JButton btnQuitarStock;

    private JButton btnActualizarPrecio;

    private JTextField txtNuevoPrecio;

    private JTable tablaProductos;

    private static final Color COLOR_FONDO =
        new Color(241, 245, 249);

    private static final Color COLOR_HEADER =
        new Color(15, 23, 42);

    private static final Color COLOR_AZUL =
        new Color(37, 99, 235);

    private static final Color COLOR_VERDE =
        new Color(22, 163, 74);

    private static final Color COLOR_NARANJA =
        new Color(234, 88, 12);

    private static final Color COLOR_BORDE =
        new Color(203, 213, 225);

    private static final Color COLOR_GRIS =
        new Color(100, 116, 139);

    public AlmacenVista() {

        setLayout(null);

        setBounds(0, 0, 960, 700);

        setBackground(new Color(241, 245, 249));

        // ==================
        // HEADER
        // ==================

        JPanel panelHeader = new JPanel();

        panelHeader.setBackground(COLOR_HEADER);

        panelHeader.setLayout(null);

        panelHeader.setBounds(0, 0, 960, 75);

        add(panelHeader);



        JPanel barraAcento = new JPanel();

        barraAcento.setBackground(COLOR_NARANJA);

        barraAcento.setBounds(0, 0, 4, 75);

        panelHeader.add(barraAcento);



        JLabel lblTitulo = new JLabel(
            "Gestion de Almacen"
        );

        lblTitulo.setForeground(Color.WHITE);

        lblTitulo.setFont(
            new Font("Arial Black", Font.BOLD, 22)
        );

        lblTitulo.setBounds(25, 14, 400, 30);

        panelHeader.add(lblTitulo);



        JLabel lblSub = new JLabel(
            "Controla entradas, salidas y precios"
        );

        lblSub.setForeground(
            new Color(148, 163, 184)
        );

        lblSub.setFont(
            new Font("Arial", Font.PLAIN, 12)
        );

        lblSub.setBounds(25, 46, 400, 18);

        panelHeader.add(lblSub);



        // ==================
        // PANEL STOCK
        // ==================

        JPanel panelStock = new JPanel();

        panelStock.setBackground(Color.WHITE);

        panelStock.setLayout(null);

        panelStock.setBounds(20, 90, 440, 160);

        panelStock.setBorder(
            BorderFactory.createLineBorder(
                new Color(226, 232, 240)
            )
        );

        add(panelStock);



        JPanel barraStock = new JPanel();

        barraStock.setBackground(COLOR_VERDE);

        barraStock.setBounds(0, 0, 4, 160);

        panelStock.add(barraStock);



        JLabel lblSubStock = new JLabel(
            "Entrada / Salida de Mercancia"
        );

        lblSubStock.setFont(
            new Font("Arial", Font.BOLD, 14)
        );

        lblSubStock.setForeground(
            new Color(30, 41, 59)
        );

        lblSubStock.setBounds(15, 12, 350, 22);

        panelStock.add(lblSubStock);



        JPanel lineaStock = new JPanel();

        lineaStock.setBackground(
            new Color(226, 232, 240)
        );

        lineaStock.setBounds(15, 38, 410, 1);

        panelStock.add(lineaStock);



        JLabel lblId = new JLabel("ID Producto");

        lblId.setFont(
            new Font("Arial", Font.BOLD, 12)
        );

        lblId.setForeground(
            new Color(30, 41, 59)
        );

        lblId.setBounds(15, 48, 120, 18);

        panelStock.add(lblId);



        txtIdProducto = new JTextField();

        txtIdProducto.setBounds(15, 68, 130, 38);

        txtIdProducto.setFont(
            new Font("Arial", Font.PLAIN, 14)
        );

        txtIdProducto.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    COLOR_BORDE
                ),
                BorderFactory.createEmptyBorder(
                    5, 10, 5, 10
                )
            )
        );

        txtIdProducto.setBackground(
            new Color(248, 250, 252)
        );

        panelStock.add(txtIdProducto);



        JLabel lblCant = new JLabel("Cantidad");

        lblCant.setFont(
            new Font("Arial", Font.BOLD, 12)
        );

        lblCant.setForeground(
            new Color(30, 41, 59)
        );

        lblCant.setBounds(160, 48, 100, 18);

        panelStock.add(lblCant);



        txtCantidad = new JTextField();

        txtCantidad.setBounds(160, 68, 110, 38);

        txtCantidad.setFont(
            new Font("Arial", Font.PLAIN, 14)
        );

        txtCantidad.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    COLOR_BORDE
                ),
                BorderFactory.createEmptyBorder(
                    5, 10, 5, 10
                )
            )
        );

        txtCantidad.setBackground(
            new Color(248, 250, 252)
        );

        panelStock.add(txtCantidad);



        btnAgregarStock = new JButton(
            "+"
        );

        btnAgregarStock.setBounds(280, 68, 70, 38);

        btnAgregarStock.setBackground(COLOR_VERDE);

        btnAgregarStock.setForeground(Color.WHITE);

        btnAgregarStock.setFont(
            new Font("Arial", Font.BOLD, 12)
        );

        btnAgregarStock.setFocusPainted(false);

        btnAgregarStock.setBorderPainted(false);

        btnAgregarStock.setCursor(
            new java.awt.Cursor(
                java.awt.Cursor.HAND_CURSOR
            )
        );

        panelStock.add(btnAgregarStock);



        btnQuitarStock = new JButton(
            "-"
        );

        btnQuitarStock.setBounds(355, 68, 70, 38);

        btnQuitarStock.setBackground(COLOR_NARANJA);

        btnQuitarStock.setForeground(Color.WHITE);

        btnQuitarStock.setFont(
            new Font("Arial", Font.BOLD, 12)
        );

        btnQuitarStock.setFocusPainted(false);

        btnQuitarStock.setBorderPainted(false);

        btnQuitarStock.setCursor(
            new java.awt.Cursor(
                java.awt.Cursor.HAND_CURSOR
            )
        );

        panelStock.add(btnQuitarStock);



        JLabel lblHint = new JLabel(
            "Entrada: agrega stock.   "
            + "Salida: descuenta mercancia"
        );

        lblHint.setFont(
            new Font("Arial", Font.ITALIC, 11)
        );

        lblHint.setForeground(COLOR_GRIS);

        lblHint.setBounds(15, 118, 410, 18);

        panelStock.add(lblHint);



        // ==================
        // PANEL PRECIO
        // ==================

        JPanel panelPrecio = new JPanel();

        panelPrecio.setBackground(Color.WHITE);

        panelPrecio.setLayout(null);

        panelPrecio.setBounds(480, 90, 460, 160);

        panelPrecio.setBorder(
            BorderFactory.createLineBorder(
                new Color(226, 232, 240)
            )
        );

        add(panelPrecio);



        JPanel barraPrecio = new JPanel();

        barraPrecio.setBackground(COLOR_AZUL);

        barraPrecio.setBounds(0, 0, 4, 160);

        panelPrecio.add(barraPrecio);



        JLabel lblSubPrecio = new JLabel(
            "Cambiar Precio de Venta"
        );

        lblSubPrecio.setFont(
            new Font("Arial", Font.BOLD, 14)
        );

        lblSubPrecio.setForeground(
            new Color(30, 41, 59)
        );

        lblSubPrecio.setBounds(15, 12, 350, 22);

        panelPrecio.add(lblSubPrecio);



        JPanel lineaPrecio = new JPanel();

        lineaPrecio.setBackground(
            new Color(226, 232, 240)
        );

        lineaPrecio.setBounds(15, 38, 430, 1);

        panelPrecio.add(lineaPrecio);



        JLabel lblNuevoPrecio = new JLabel(
            "Nuevo Precio"
        );

        lblNuevoPrecio.setFont(
            new Font("Arial", Font.BOLD, 12)
        );

        lblNuevoPrecio.setForeground(
            new Color(30, 41, 59)
        );

        lblNuevoPrecio.setBounds(15, 48, 150, 18);

        panelPrecio.add(lblNuevoPrecio);



        txtNuevoPrecio = new JTextField();

        txtNuevoPrecio.setBounds(15, 68, 160, 38);

        txtNuevoPrecio.setFont(
            new Font("Arial", Font.PLAIN, 14)
        );

        txtNuevoPrecio.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    COLOR_BORDE
                ),
                BorderFactory.createEmptyBorder(
                    5, 10, 5, 10
                )
            )
        );

        txtNuevoPrecio.setBackground(
            new Color(248, 250, 252)
        );

        panelPrecio.add(txtNuevoPrecio);



        btnActualizarPrecio = new JButton(
            "Actualizar Precio"
        );

        btnActualizarPrecio.setBounds(
            190, 68, 180, 38
        );

        btnActualizarPrecio.setBackground(
            COLOR_AZUL
        );

        btnActualizarPrecio.setForeground(
            Color.WHITE
        );

        btnActualizarPrecio.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        btnActualizarPrecio.setFocusPainted(false);

        btnActualizarPrecio.setBorderPainted(false);

        btnActualizarPrecio.setCursor(
            new java.awt.Cursor(
                java.awt.Cursor.HAND_CURSOR
            )
        );

        panelPrecio.add(btnActualizarPrecio);



        JLabel lblHintPrecio = new JLabel(
            "Selecciona un producto de la tabla "
            + "y escribe el nuevo precio"
        );

        lblHintPrecio.setFont(
            new Font("Arial", Font.ITALIC, 11)
        );

        lblHintPrecio.setForeground(COLOR_GRIS);

        lblHintPrecio.setBounds(15, 118, 430, 18);

        panelPrecio.add(lblHintPrecio);



        // ==================
        // TABLA
        // ==================

        JPanel panelTabla = new JPanel();

        panelTabla.setBackground(Color.WHITE);

        panelTabla.setLayout(null);

        panelTabla.setBounds(20, 268, 950, 330);

        panelTabla.setBorder(
            BorderFactory.createLineBorder(
                new Color(226, 232, 240)
            )
        );

        add(panelTabla);



        JPanel barraTabla = new JPanel();

        barraTabla.setBackground(COLOR_NARANJA);

        barraTabla.setBounds(0, 0, 4, 330);

        panelTabla.add(barraTabla);



        JLabel lblTabTit = new JLabel(
            "Inventario de Productos"
        );

        lblTabTit.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        lblTabTit.setForeground(
            new Color(30, 41, 59)
        );

        lblTabTit.setBounds(15, 10, 300, 20);

        panelTabla.add(lblTabTit);



        JPanel lineaTabla = new JPanel();

        lineaTabla.setBackground(
            new Color(226, 232, 240)
        );

        lineaTabla.setBounds(15, 34, 900, 1);

        panelTabla.add(lineaTabla);



        JScrollPane scroll = new JScrollPane();

        scroll.setBounds(8, 40, 905, 280);

        scroll.setBorder(null);

        panelTabla.add(scroll);



        tablaProductos = new JTable() {

            private static final long
                serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(
                int row,
                int column
            ) {
                return false;
            }
        };

        tablaProductos.setRowHeight(30);

        tablaProductos.setFont(
            new Font("Arial", Font.PLAIN, 13)
        );

        tablaProductos.getTableHeader().setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        tablaProductos.getTableHeader()
            .setBackground(
                new Color(241, 245, 249)
            );

        tablaProductos.setGridColor(
            new Color(241, 245, 249)
        );

        tablaProductos.setSelectionBackground(
            new Color(255, 237, 213)
        );

        tablaProductos.setSelectionForeground(
            new Color(154, 52, 18)
        );

        scroll.setViewportView(tablaProductos);
    }

    public JTextField getTxtIdProducto() {
        return txtIdProducto;
    }

    public JTextField getTxtCantidad() {
        return txtCantidad;
    }

    public JTextField getTxtNuevoPrecio() {
        return txtNuevoPrecio;
    }

    public JButton getBtnAgregarStock() {
        return btnAgregarStock;
    }

    public JButton getBtnQuitarStock() {
        return btnQuitarStock;
    }

    public JButton getBtnActualizarPrecio() {
        return btnActualizarPrecio;
    }

    public JTable getTablaProductos() {
        return tablaProductos;
    }
}