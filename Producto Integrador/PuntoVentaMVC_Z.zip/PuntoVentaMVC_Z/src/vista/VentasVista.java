package vista;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class VentasVista extends JPanel {

    private static final long serialVersionUID = 1L;
    private JTextField txtProducto;

    private JTextField txtCantidad;

    private JTextField txtDescuento;

    private JButton btnAgregar;

    private JButton btnEliminarItem;

    private JButton btnVender;

    private JButton btnLimpiar;

    private JTable tablaVenta;

    private JLabel lblTotal;

    private JLabel lblDescuentoMuestra;

    private JLabel lblMontoPagar;

    private static final Color COLOR_AZUL =
        new Color(37, 99, 235);

    private static final Color COLOR_FONDO =
        new Color(241, 245, 249);

    private static final Color COLOR_VERDE =
        new Color(22, 163, 74);

    private static final Color COLOR_ROJO =
        new Color(220, 38, 38);

    private static final Color COLOR_GRIS =
        new Color(100, 116, 139);

    private static final Color COLOR_BORDE =
        new Color(203, 213, 225);

    public VentasVista() {

        setLayout(null);
        setBounds(0, 0, 960, 700);
        setBackground(new Color(241, 245, 249));

        // ==================
        // HEADER
        // ==================

        JPanel panelHeader = new JPanel();

        panelHeader.setBackground(COLOR_VERDE);

        panelHeader.setLayout(null);

        panelHeader.setBounds(0, 0, 960, 75);

        add(panelHeader);



        JPanel barraAcento = new JPanel();

        barraAcento.setBackground(
            new Color(21, 128, 61)
        );

        barraAcento.setBounds(0, 0, 4, 75);

        panelHeader.add(barraAcento);



        JLabel lblTitulo = new JLabel(
            "Modulo de Ventas"
        );

        lblTitulo.setForeground(Color.WHITE);

        lblTitulo.setFont(
            new Font("Arial Black", Font.BOLD, 22)
        );

        lblTitulo.setBounds(25, 14, 400, 30);

        panelHeader.add(lblTitulo);



        JLabel lblSub = new JLabel(
            "Registra productos y finaliza la venta"
        );

        lblSub.setForeground(
            new Color(187, 247, 208)
        );

        lblSub.setFont(
            new Font("Arial", Font.PLAIN, 12)
        );

        lblSub.setBounds(25, 46, 400, 18);

        panelHeader.add(lblSub);



        // ==================
        // PANEL ENTRADA
        // ==================

        JPanel panelEntrada = new JPanel();

        panelEntrada.setBackground(Color.WHITE);

        panelEntrada.setLayout(null);

        panelEntrada.setBounds(20, 90, 600, 130);

        panelEntrada.setBorder(
            BorderFactory.createLineBorder(
                new Color(226, 232, 240)
            )
        );

        add(panelEntrada);



        JPanel barraEntrada = new JPanel();

        barraEntrada.setBackground(COLOR_AZUL);

        barraEntrada.setBounds(0, 0, 4, 130);

        panelEntrada.add(barraEntrada);



        JLabel lblProducto = new JLabel(
            "ID Producto"
        );

        lblProducto.setFont(
            new Font("Arial", Font.BOLD, 12)
        );

        lblProducto.setForeground(
            new Color(30, 41, 59)
        );

        lblProducto.setBounds(18, 14, 120, 18);

        panelEntrada.add(lblProducto);



        txtProducto = new JTextField();

        txtProducto.setBounds(18, 35, 150, 38);

        txtProducto.setFont(
            new Font("Arial", Font.PLAIN, 14)
        );

        txtProducto.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    COLOR_BORDE
                ),
                BorderFactory.createEmptyBorder(
                    5, 10, 5, 10
                )
            )
        );

        txtProducto.setBackground(
            new Color(248, 250, 252)
        );

        panelEntrada.add(txtProducto);



        JLabel lblCantidad = new JLabel(
            "Cantidad"
        );

        lblCantidad.setFont(
            new Font("Arial", Font.BOLD, 12)
        );

        lblCantidad.setForeground(
            new Color(30, 41, 59)
        );

        lblCantidad.setBounds(188, 14, 100, 18);

        panelEntrada.add(lblCantidad);



        txtCantidad = new JTextField();

        txtCantidad.setBounds(188, 35, 120, 38);

        txtCantidad.setFont(
            new Font("Arial", Font.PLAIN, 14)
        );

        txtCantidad.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    COLOR_BORDE
                ),
                BorderFactory.createEmptyBorder(
                    5, 10, 5, 10
                )
            )
        );

        txtCantidad.setBackground(
            new Color(248, 250, 252)
        );

        panelEntrada.add(txtCantidad);



        btnAgregar = new JButton("+ Agregar");

        btnAgregar.setBounds(325, 35, 120, 38);

        btnAgregar.setBackground(COLOR_AZUL);

        btnAgregar.setForeground(Color.WHITE);

        btnAgregar.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        btnAgregar.setFocusPainted(false);

        btnAgregar.setBorderPainted(false);

        btnAgregar.setCursor(
            new java.awt.Cursor(
                java.awt.Cursor.HAND_CURSOR
            )
        );

        panelEntrada.add(btnAgregar);



        btnEliminarItem = new JButton("Quitar");

        btnEliminarItem.setBounds(460, 35, 120, 38);

        btnEliminarItem.setBackground(COLOR_ROJO);

        btnEliminarItem.setForeground(Color.WHITE);

        btnEliminarItem.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        btnEliminarItem.setFocusPainted(false);

        btnEliminarItem.setBorderPainted(false);

        btnEliminarItem.setCursor(
            new java.awt.Cursor(
                java.awt.Cursor.HAND_CURSOR
            )
        );

        panelEntrada.add(btnEliminarItem);



        JLabel lblHint = new JLabel(
            "Selecciona una fila y clic en "
            + "Quitar para eliminar un producto"
        );

        lblHint.setFont(
            new Font("Arial", Font.ITALIC, 11)
        );

        lblHint.setForeground(COLOR_GRIS);

        lblHint.setBounds(18, 88, 660, 20);

        panelEntrada.add(lblHint);



        // ==================
        // PANEL DESCUENTO
        // ==================

        JPanel panelDesc = new JPanel();

        panelDesc.setBackground(Color.WHITE);

        panelDesc.setLayout(null);

        panelDesc.setBounds(640, 90, 300, 130);

        panelDesc.setBorder(
            BorderFactory.createLineBorder(
                new Color(226, 232, 240)
            )
        );

        add(panelDesc);



        JPanel barraDesc = new JPanel();

        barraDesc.setBackground(COLOR_ROJO);

        barraDesc.setBounds(0, 0, 4, 130);

        panelDesc.add(barraDesc);



        JLabel lblDescTit = new JLabel(
            "Descuento (%)"
        );

        lblDescTit.setFont(
            new Font("Arial", Font.BOLD, 12)
        );

        lblDescTit.setForeground(
            new Color(30, 41, 59)
        );

        lblDescTit.setBounds(15, 14, 180, 18);

        panelDesc.add(lblDescTit);



        txtDescuento = new JTextField("0");

        txtDescuento.setBounds(15, 35, 140, 38);

        txtDescuento.setFont(
            new Font("Arial", Font.PLAIN, 15)
        );

        txtDescuento.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    COLOR_BORDE
                ),
                BorderFactory.createEmptyBorder(
                    5, 10, 5, 10
                )
            )
        );

        txtDescuento.setBackground(
            new Color(248, 250, 252)
        );

        panelDesc.add(txtDescuento);



        lblDescuentoMuestra = new JLabel(
            "Descuento: $0.00"
        );

        lblDescuentoMuestra.setFont(
            new Font("Arial", Font.BOLD, 12)
        );

        lblDescuentoMuestra.setForeground(
            COLOR_ROJO
        );

        lblDescuentoMuestra.setBounds(15, 88, 270, 22);

        panelDesc.add(lblDescuentoMuestra);



        // ==================
        // TABLA
        // ==================

        JPanel panelTabla = new JPanel();

        panelTabla.setBackground(Color.WHITE);

        panelTabla.setLayout(null);

        panelTabla.setBounds(20, 238, 920, 270);

        panelTabla.setBorder(
            BorderFactory.createLineBorder(
                new Color(226, 232, 240)
            )
        );

        add(panelTabla);



        JPanel barraTabla = new JPanel();

        barraTabla.setBackground(COLOR_VERDE);

        barraTabla.setBounds(0, 0, 4, 270);

        panelTabla.add(barraTabla);



        JLabel lblTabTit = new JLabel(
            "Productos en esta venta"
        );

        lblTabTit.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        lblTabTit.setForeground(
            new Color(30, 41, 59)
        );

        lblTabTit.setBounds(15, 10, 300, 20);

        panelTabla.add(lblTabTit);



        JPanel lineaTabla = new JPanel();

        lineaTabla.setBackground(
            new Color(226, 232, 240)
        );

        lineaTabla.setBounds(15, 34, 890, 1);

        panelTabla.add(lineaTabla);



        JScrollPane scroll = new JScrollPane();

        scroll.setBounds(8, 38, 900, 222);

        scroll.setBorder(null);

        panelTabla.add(scroll);



        tablaVenta = new JTable() {

            private static final long
                serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(
                int row,
                int column
            ) {
                return false;
            }
        };

        tablaVenta.setRowHeight(30);

        tablaVenta.setFont(
            new Font("Arial", Font.PLAIN, 13)
        );

        tablaVenta.getTableHeader().setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        tablaVenta.getTableHeader().setBackground(
            new Color(241, 245, 249)
        );

        tablaVenta.setGridColor(
            new Color(241, 245, 249)
        );

        tablaVenta.setSelectionBackground(
            new Color(220, 252, 231)
        );

        tablaVenta.setSelectionForeground(
            new Color(21, 128, 61)
        );

        scroll.setViewportView(tablaVenta);



        // ==================
        // PANEL TOTALES
        // ==================

        JPanel panelTotales = new JPanel();

        panelTotales.setBackground(Color.WHITE);

        panelTotales.setLayout(null);

        panelTotales.setBounds(555, 523, 385, 90);;

        panelTotales.setBorder(
            BorderFactory.createLineBorder(
                new Color(226, 232, 240)
            )
        );

        add(panelTotales);



        JPanel barraTotales = new JPanel();

        barraTotales.setBackground(COLOR_VERDE);

        barraTotales.setBounds(0, 0, 4, 90);

        panelTotales.add(barraTotales);



        lblTotal = new JLabel("Subtotal: $0.00");

        lblTotal.setFont(
            new Font("Arial", Font.PLAIN, 14)
        );

        lblTotal.setForeground(COLOR_GRIS);

        lblTotal.setBounds(15, 10, 360, 22);

        panelTotales.add(lblTotal);



        lblDescuentoMuestra = new JLabel(
            "Descuento: $0.00"
        );

        lblDescuentoMuestra.setFont(
            new Font("Arial", Font.PLAIN, 12)
        );

        lblDescuentoMuestra.setForeground(COLOR_ROJO);

        lblDescuentoMuestra.setBounds(15, 32, 360, 18);

        panelTotales.add(lblDescuentoMuestra);



        lblMontoPagar = new JLabel(
            "TOTAL A PAGAR:  $0.00"
        );

        lblMontoPagar.setFont(
            new Font("Arial Black", Font.BOLD, 17)
        );

        lblMontoPagar.setForeground(COLOR_VERDE);

        lblMontoPagar.setBounds(15, 54, 360, 26);

        panelTotales.add(lblMontoPagar);



        // Botones inferiores
        btnLimpiar = new JButton("Limpiar");

        btnLimpiar.setBounds(20, 528, 140, 42);

        btnLimpiar.setBackground(COLOR_GRIS);

        btnLimpiar.setForeground(Color.WHITE);

        btnLimpiar.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        btnLimpiar.setFocusPainted(false);

        btnLimpiar.setBorderPainted(false);

        btnLimpiar.setCursor(
            new java.awt.Cursor(
                java.awt.Cursor.HAND_CURSOR
            )
        );

        add(btnLimpiar);



        btnVender = new JButton("Finalizar Venta");

        btnVender.setBounds(190, 523, 220, 50);

        btnVender.setBackground(COLOR_VERDE);

        btnVender.setForeground(Color.WHITE);

        btnVender.setFont(
            new Font("Arial Black", Font.BOLD, 14)
        );

        btnVender.setFocusPainted(false);

        btnVender.setBorderPainted(false);

        btnVender.setCursor(
            new java.awt.Cursor(
                java.awt.Cursor.HAND_CURSOR
            )
        );

        add(btnVender);
    }

    public JTextField getTxtProducto() {
        return txtProducto;
    }

    public JTextField getTxtCantidad() {
        return txtCantidad;
    }

    public JTextField getTxtDescuento() {
        return txtDescuento;
    }

    public JButton getBtnAgregar() {
        return btnAgregar;
    }

    public JButton getBtnEliminarItem() {
        return btnEliminarItem;
    }

    public JButton getBtnVender() {
        return btnVender;
    }

    public JButton getBtnLimpiar() {
        return btnLimpiar;
    }

    public JTable getTablaVenta() {
        return tablaVenta;
    }

    public JLabel getLblTotal() {
        return lblTotal;
    }

    public JLabel getLblDescuentoMuestra() {
        return lblDescuentoMuestra;
    }

    public JLabel getLblMontoPagar() {
        return lblMontoPagar;
    }
}