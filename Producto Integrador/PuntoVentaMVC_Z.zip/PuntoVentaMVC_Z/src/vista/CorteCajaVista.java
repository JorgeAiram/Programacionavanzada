package vista;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class CorteCajaVista extends JPanel {

    private static final long serialVersionUID = 1L;
    private JTextField txtFondoInicial;

    private JTextField txtEfectivoContado;

    private JTextField txtObservaciones;

    private JButton btnAbrirCorte;

    private JButton btnCerrarCorte;

    private JTable tablaCortes;

    private JLabel lblEstado;

    private JLabel lblFondoInicial;

    private JLabel lblVentasHoy;

    private JLabel lblTotalSistema;

    private JLabel lblDiferencia;

    private static final Color COLOR_FONDO =
        new Color(241, 245, 249);

    private static final Color COLOR_HEADER =
        new Color(15, 23, 42);

    private static final Color COLOR_VERDE =
        new Color(22, 163, 74);

    private static final Color COLOR_ROJO =
        new Color(220, 38, 38);

    private static final Color COLOR_AZUL =
        new Color(37, 99, 235);

    private static final Color COLOR_NARANJA =
        new Color(234, 88, 12);

    private static final Color COLOR_BORDE =
        new Color(203, 213, 225);

    private static final Color COLOR_GRIS =
        new Color(100, 116, 139);

    public CorteCajaVista() {

    	setLayout(null);

    	setBounds(0, 0, 960, 700);

    	setBackground(new Color(241, 245, 249));

    	// ==================
    	// HEADER
    	// ==================

    	JPanel panelHeader = new JPanel();

    	panelHeader.setBackground(COLOR_HEADER);

    	panelHeader.setLayout(null);

    	panelHeader.setBounds(0, 0, 960, 75);

    	add(panelHeader);



    	JPanel barraAcento = new JPanel();

    	barraAcento.setBackground(COLOR_VERDE);

    	barraAcento.setBounds(0, 0, 4, 75);

    	panelHeader.add(barraAcento);



    	JLabel lblTitulo = new JLabel(
    	    "Corte de Caja"
    	);

    	lblTitulo.setForeground(Color.WHITE);

    	lblTitulo.setFont(
    	    new Font("Arial Black", Font.BOLD, 22)
    	);

    	lblTitulo.setBounds(25, 14, 400, 30);

    	panelHeader.add(lblTitulo);



    	JLabel lblSub = new JLabel(
    	    "Apertura, cierre e historial de cortes"
    	);

    	lblSub.setForeground(
    	    new Color(148, 163, 184)
    	);

    	lblSub.setFont(
    	    new Font("Arial", Font.PLAIN, 12)
    	);

    	lblSub.setBounds(25, 46, 400, 18);

    	panelHeader.add(lblSub);



    	lblEstado = new JLabel("SIN CORTE ABIERTO");

    	lblEstado.setFont(
    	    new Font("Arial", Font.BOLD, 13)
    	);

    	lblEstado.setForeground(COLOR_NARANJA);

    	lblEstado.setHorizontalAlignment(
    	    SwingConstants.RIGHT
    	);

    	lblEstado.setBounds(500, 25, 430, 25);

    	panelHeader.add(lblEstado);



    	// ==================
    	// PANEL RESUMEN
    	// ==================

    	JPanel panelResumen = new JPanel();

    	panelResumen.setBackground(Color.WHITE);

    	panelResumen.setLayout(null);

    	panelResumen.setBounds(20, 90, 560, 160);

    	panelResumen.setBorder(
    	    BorderFactory.createLineBorder(
    	        new Color(226, 232, 240)
    	    )
    	);

    	add(panelResumen);



    	JPanel barraResumen = new JPanel();

    	barraResumen.setBackground(COLOR_AZUL);

    	barraResumen.setBounds(0, 0, 4, 160);

    	panelResumen.add(barraResumen);



    	JLabel lblResTit = new JLabel(
    	    "Resumen del Corte Actual"
    	);

    	lblResTit.setFont(
    	    new Font("Arial", Font.BOLD, 14)
    	);

    	lblResTit.setForeground(
    	    new Color(30, 41, 59)
    	);

    	lblResTit.setBounds(15, 12, 350, 20);

    	panelResumen.add(lblResTit);



    	JPanel lineaRes = new JPanel();

    	lineaRes.setBackground(
    	    new Color(226, 232, 240)
    	);

    	lineaRes.setBounds(15, 36, 530, 1);

    	panelResumen.add(lineaRes);



    	// Tarjetas de resumen
    	agregarTarjetaResumen(
    	    panelResumen, "Fondo Inicial",
    	    15, 48, COLOR_AZUL
    	);

    	lblFondoInicial = new JLabel("$0.00");

    	lblFondoInicial.setFont(
    	    new Font("Arial Black", Font.BOLD, 16)
    	);

    	lblFondoInicial.setForeground(COLOR_AZUL);

    	lblFondoInicial.setBounds(15, 80, 120, 25);

    	panelResumen.add(lblFondoInicial);



    	agregarTarjetaResumen(
    	    panelResumen, "Ventas del Dia",
    	    150, 48, COLOR_VERDE
    	);

    	lblVentasHoy = new JLabel("$0.00");

    	lblVentasHoy.setFont(
    	    new Font("Arial Black", Font.BOLD, 16)
    	);

    	lblVentasHoy.setForeground(COLOR_VERDE);

    	lblVentasHoy.setBounds(150, 80, 120, 25);

    	panelResumen.add(lblVentasHoy);



    	agregarTarjetaResumen(
    	    panelResumen, "Total Sistema",
    	    285, 48, COLOR_NARANJA
    	);

    	lblTotalSistema = new JLabel("$0.00");

    	lblTotalSistema.setFont(
    	    new Font("Arial Black", Font.BOLD, 16)
    	);

    	lblTotalSistema.setForeground(COLOR_NARANJA);

    	lblTotalSistema.setBounds(285, 80, 120, 25);

    	panelResumen.add(lblTotalSistema);



    	agregarTarjetaResumen(
    	    panelResumen, "Diferencia",
    	    420, 48, COLOR_GRIS
    	);

    	lblDiferencia = new JLabel("$0.00");

    	lblDiferencia.setFont(
    	    new Font("Arial Black", Font.BOLD, 16)
    	);

    	lblDiferencia.setForeground(COLOR_GRIS);

    	lblDiferencia.setBounds(420, 80, 120, 25);

    	panelResumen.add(lblDiferencia);



    	JLabel lblHintRes = new JLabel(
    	    "La diferencia se calcula al realizar el cierre"
    	);

    	lblHintRes.setFont(
    	    new Font("Arial", Font.ITALIC, 11)
    	);

    	lblHintRes.setForeground(COLOR_GRIS);

    	lblHintRes.setBounds(15, 125, 500, 18);

    	panelResumen.add(lblHintRes);



    	// ==================
    	// PANEL ACCIONES
    	// ==================

    	JPanel panelAcciones = new JPanel();

    	panelAcciones.setBackground(Color.WHITE);

    	panelAcciones.setLayout(null);

    	panelAcciones.setBounds(600, 90, 340, 160);

    	panelAcciones.setBorder(
    	    BorderFactory.createLineBorder(
    	        new Color(226, 232, 240)
    	    )
    	);

    	add(panelAcciones);



    	JPanel barraAcc = new JPanel();

    	barraAcc.setBackground(COLOR_VERDE);

    	barraAcc.setBounds(0, 0, 4, 160);

    	panelAcciones.add(barraAcc);



    	JLabel lblAccTit = new JLabel(
    	    "Acciones"
    	);

    	lblAccTit.setFont(
    	    new Font("Arial", Font.BOLD, 14)
    	);

    	lblAccTit.setForeground(
    	    new Color(30, 41, 59)
    	);

    	lblAccTit.setBounds(15, 12, 200, 20);

    	panelAcciones.add(lblAccTit);



    	JPanel lineaAcc = new JPanel();

    	lineaAcc.setBackground(
    	    new Color(226, 232, 240)
    	);

    	lineaAcc.setBounds(15, 36, 310, 1);

    	panelAcciones.add(lineaAcc);



    	txtFondoInicial = new JTextField("0.00");

    	txtFondoInicial.setBounds(15, 64, 140, 36);

    	panelAcciones.add(txtFondoInicial);



    	btnAbrirCorte = new JButton(
    	    "Abrir Corte"
    	);

    	btnAbrirCorte.setBounds(170, 64, 150, 36);

    	panelAcciones.add(btnAbrirCorte);



    	txtEfectivoContado = new JTextField("0.00");

    	txtEfectivoContado.setBounds(
    	    15, 126, 140, 26
    	);

    	panelAcciones.add(txtEfectivoContado);



    	btnCerrarCorte = new JButton(
    	    "Cerrar Corte"
    	);

    	btnCerrarCorte.setBounds(170, 126, 150, 26);

    	panelAcciones.add(btnCerrarCorte);



    	// ==================
    	// OBSERVACIONES
    	// ==================

    	JPanel panelObs = new JPanel();

    	panelObs.setBackground(Color.WHITE);

    	panelObs.setLayout(null);

    	panelObs.setBounds(20, 265, 920, 65);

    	panelObs.setBorder(
    	    BorderFactory.createLineBorder(
    	        new Color(226, 232, 240)
    	    )
    	);

    	add(panelObs);



    	txtObservaciones = new JTextField();

    	txtObservaciones.setBounds(
    	    15, 30, 890, 28
    	);

    	panelObs.add(txtObservaciones);



    	// ==================
    	// TABLA HISTORIAL
    	// ==================

    	JPanel panelTabla = new JPanel();

    	panelTabla.setBackground(Color.WHITE);

    	panelTabla.setLayout(null);

    	panelTabla.setBounds(20, 345, 920, 300);

    	panelTabla.setBorder(
    	    BorderFactory.createLineBorder(
    	        new Color(226, 232, 240)
    	    )
    	);

    	add(panelTabla);



    	JPanel barraTabla = new JPanel();

    	barraTabla.setBackground(COLOR_HEADER);

    	barraTabla.setBounds(0, 0, 4, 300);

    	panelTabla.add(barraTabla);



    	JScrollPane scroll = new JScrollPane();

    	scroll.setBounds(8, 40, 900, 250);

    	scroll.setBorder(null);

    	panelTabla.add(scroll);



        tablaCortes = new JTable() {

            private static final long
                serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(
                int row, int column
            ) {
                return false;
            }
        };

        tablaCortes.setRowHeight(30);

        tablaCortes.setFont(
            new Font("Arial", Font.PLAIN, 12)
        );

        tablaCortes.getTableHeader().setFont(
            new Font("Arial", Font.BOLD, 12)
        );

        tablaCortes.getTableHeader()
            .setBackground(
                new Color(241, 245, 249)
            );

        tablaCortes.setGridColor(
            new Color(241, 245, 249)
        );

        tablaCortes.setSelectionBackground(
            new Color(220, 252, 231)
        );

        tablaCortes.setSelectionForeground(
            new Color(21, 128, 61)
        );

        scroll.setViewportView(tablaCortes);
    }

    private void agregarTarjetaResumen(
        JPanel panel,
        String titulo,
        int x,
        int y,
        Color color
    ) {

        JLabel lbl = new JLabel(titulo);

        lbl.setFont(
            new Font("Arial", Font.BOLD, 11)
        );

        lbl.setForeground(color);

        lbl.setBounds(x, y, 150, 16);

        panel.add(lbl);
    }

    public JTextField getTxtFondoInicial() {
        return txtFondoInicial;
    }

    public JTextField getTxtEfectivoContado() {
        return txtEfectivoContado;
    }

    public JTextField getTxtObservaciones() {
        return txtObservaciones;
    }

    public JButton getBtnAbrirCorte() {
        return btnAbrirCorte;
    }

    public JButton getBtnCerrarCorte() {
        return btnCerrarCorte;
    }

    public JTable getTablaCortes() {
        return tablaCortes;
    }

    public JLabel getLblEstado() {
        return lblEstado;
    }

    public JLabel getLblFondoInicial() {
        return lblFondoInicial;
    }

    public JLabel getLblVentasHoy() {
        return lblVentasHoy;
    }

    public JLabel getLblTotalSistema() {
        return lblTotalSistema;
    }

    public JLabel getLblDiferencia() {
        return lblDiferencia;
    }
}