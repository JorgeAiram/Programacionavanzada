package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.table.DefaultTableModel;

import util.ErrorControlador;

public class VentaPersistencia {

    public int guardarVenta(
        double total,
        double descuento,
        double montoPagar
    ) {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "INSERT INTO ventas("
                + "total, descuento, monto_pagar"
                + ") "
                + "VALUES(?,?,?)";

            PreparedStatement statement =
                conexion.prepareStatement(
                    sql,
                    PreparedStatement.RETURN_GENERATED_KEYS
                );

            statement.setDouble(1, total);

            statement.setDouble(2, descuento);

            statement.setDouble(3, montoPagar);

            statement.executeUpdate();

            ResultSet resultado =
                statement.getGeneratedKeys();

            if(resultado.next()) {

                int idVenta =
                    resultado.getInt(1);

                conexion.close();

                return idVenta;
            }

            conexion.close();

            return -1;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al guardar venta",
                e
            );

            return -1;
        }
    }

    public boolean guardarDetalleVenta(
        int idVenta,
        int idProducto,
        int cantidad,
        double precio,
        double subtotal
    ) {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "INSERT INTO detalle_ventas("
                + "id_venta, "
                + "id_producto, "
                + "cantidad, "
                + "precio, "
                + "subtotal"
                + ") "
                + "VALUES(?,?,?,?,?)";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            statement.setInt(1, idVenta);

            statement.setInt(2, idProducto);

            statement.setInt(3, cantidad);

            statement.setDouble(4, precio);

            statement.setDouble(5, subtotal);

            statement.executeUpdate();

            conexion.close();

            return true;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al guardar detalle venta",
                e
            );

            return false;
        }
    }

    public DefaultTableModel listarVentas() {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "SELECT * FROM ventas "
                + "ORDER BY id DESC";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            ResultSet resultado =
                statement.executeQuery();

            String[] columnas = {
                "ID",
                "Fecha",
                "Hora",
                "Total",
                "Descuento",
                "A Pagar"
            };

            DefaultTableModel modelo =
                new DefaultTableModel(
                    null,
                    columnas
                );

            while(resultado.next()) {

                Object[] fila = {
                    resultado.getInt("id"),
                    resultado.getString("fecha"),
                    resultado.getString("hora"),
                    resultado.getDouble("total"),
                    resultado.getDouble("descuento"),
                    resultado.getDouble("monto_pagar")
                };

                modelo.addRow(fila);
            }

            conexion.close();

            return modelo;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al listar ventas",
                e
            );

            return null;
        }
    }

    public DefaultTableModel listarVentasPorFecha(
        String fechaInicio,
        String fechaFin
    ) {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "SELECT * FROM ventas "
                + "WHERE CAST(fecha AS DATE) "
                + "BETWEEN ? AND ? "
                + "ORDER BY id DESC";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            statement.setString(1, fechaInicio);

            statement.setString(2, fechaFin);

            ResultSet resultado =
                statement.executeQuery();

            String[] columnas = {
                "ID",
                "Fecha",
                "Hora",
                "Total",
                "Descuento",
                "A Pagar"
            };

            DefaultTableModel modelo =
                new DefaultTableModel(
                    null,
                    columnas
                );

            while(resultado.next()) {

                Object[] fila = {
                    resultado.getInt("id"),
                    resultado.getString("fecha"),
                    resultado.getString("hora"),
                    resultado.getDouble("total"),
                    resultado.getDouble("descuento"),
                    resultado.getDouble("monto_pagar")
                };

                modelo.addRow(fila);
            }

            conexion.close();

            return modelo;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al filtrar ventas por fecha",
                e
            );

            return null;
        }
    }

    public DefaultTableModel obtenerDetalleVenta(
        int idVenta
    ) {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "SELECT "
                + "p.id AS codigo, "
                + "p.nombre, "
                + "d.cantidad, "
                + "d.precio, "
                + "d.subtotal "
                + "FROM detalle_ventas d "
                + "INNER JOIN productos p "
                + "ON d.id_producto = p.id "
                + "WHERE d.id_venta = ?";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            statement.setInt(1, idVenta);

            ResultSet resultado =
                statement.executeQuery();

            String[] columnas = {
                "Código",
                "Producto",
                "Cantidad",
                "Precio",
                "Subtotal"
            };

            DefaultTableModel modelo =
                new DefaultTableModel(
                    null,
                    columnas
                );

            while(resultado.next()) {

                Object[] fila = {
                    resultado.getInt("codigo"),
                    resultado.getString("nombre"),
                    resultado.getInt("cantidad"),
                    resultado.getDouble("precio"),
                    resultado.getDouble("subtotal")
                };

                modelo.addRow(fila);
            }

            conexion.close();

            return modelo;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al obtener detalle venta id="
                + idVenta,
                e
            );

            return null;
        }
    }

    public boolean guardarDevolucion(
        int idVenta,
        int idProducto,
        int cantidad,
        double montoDevuelto,
        String motivo
    ) {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "INSERT INTO devoluciones("
                + "id_venta, "
                + "id_producto, "
                + "cantidad, "
                + "monto_devuelto, "
                + "motivo"
                + ") "
                + "VALUES(?,?,?,?,?)";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            statement.setInt(1, idVenta);

            statement.setInt(2, idProducto);

            statement.setInt(3, cantidad);

            statement.setDouble(4, montoDevuelto);

            statement.setString(5, motivo);

            statement.executeUpdate();

            conexion.close();

            return true;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al guardar devolucion",
                e
            );

            return false;
        }
    }

    public DefaultTableModel listarDevoluciones() {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "SELECT "
                + "d.id, "
                + "d.id_venta, "
                + "p.nombre AS producto, "
                + "d.cantidad, "
                + "d.monto_devuelto, "
                + "d.motivo, "
                + "d.fecha "
                + "FROM devoluciones d "
                + "INNER JOIN productos p "
                + "ON d.id_producto = p.id "
                + "ORDER BY d.id DESC";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            ResultSet resultado =
                statement.executeQuery();

            String[] columnas = {
                "ID",
                "Venta",
                "Producto",
                "Cantidad",
                "Monto Dev.",
                "Motivo",
                "Fecha"
            };

            DefaultTableModel modelo =
                new DefaultTableModel(
                    null,
                    columnas
                );

            while(resultado.next()) {

                Object[] fila = {
                    resultado.getInt("id"),
                    resultado.getInt("id_venta"),
                    resultado.getString("producto"),
                    resultado.getInt("cantidad"),
                    resultado.getDouble(
                        "monto_devuelto"
                    ),
                    resultado.getString("motivo"),
                    resultado.getString("fecha")
                };

                modelo.addRow(fila);
            }

            conexion.close();

            return modelo;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al listar devoluciones",
                e
            );

            return null;
        }
    }

    public double obtenerIngresosTotales() {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "SELECT SUM(monto_pagar) "
                + "AS ingresos "
                + "FROM ventas";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            ResultSet resultado =
                statement.executeQuery();

            if(resultado.next()) {

                double ingresos =
                    resultado.getDouble("ingresos");

                conexion.close();

                return ingresos;
            }

            conexion.close();

            return 0;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al obtener ingresos",
                e
            );

            return 0;
        }
    }

    public int totalVentas() {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "SELECT COUNT(*) "
                + "AS total "
                + "FROM ventas";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            ResultSet resultado =
                statement.executeQuery();

            if(resultado.next()) {

                int total =
                    resultado.getInt("total");

                conexion.close();

                return total;
            }

            conexion.close();

            return 0;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al contar ventas",
                e
            );

            return 0;
        }
    }
}
