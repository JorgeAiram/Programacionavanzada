package persistencia;

import java.io.FileOutputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.swing.table.DefaultTableModel;

import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import util.ErrorControlador;

public class PDFReporteVentas {

    public static void exportarPDF(
        DefaultTableModel modelo,
        String resumen
    ) {

        try {

            String fecha =
                LocalDateTime.now().format(
                    DateTimeFormatter.ofPattern(
                        "yyyy-MM-dd_HH-mm"
                    )
                );

            String nombre =
                "Reporte_Ventas_"
                + fecha + ".pdf";

            Document documento =
                new Document(PageSize.A4);

            PdfWriter.getInstance(
                documento,
                new FileOutputStream(nombre)
            );

            documento.open();



            // Titulo
            Font fuenteTitulo =
                FontFactory.getFont(
                    FontFactory.HELVETICA_BOLD,
                    20
                );

            Paragraph titulo =
                new Paragraph(
                    "REPORTE DE VENTAS\n",
                    fuenteTitulo
                );

            titulo.setAlignment(
                Element.ALIGN_CENTER
            );

            documento.add(titulo);



            // Fecha de generacion
            Font fuenteSub =
                FontFactory.getFont(
                    FontFactory.HELVETICA,
                    10
                );

            Paragraph sub =
                new Paragraph(
                    "Generado el: "
                    + LocalDateTime.now().format(
                        DateTimeFormatter.ofPattern(
                            "dd/MM/yyyy HH:mm"
                        )
                    ) + "\n\n",
                    fuenteSub
                );

            sub.setAlignment(
                Element.ALIGN_CENTER
            );

            documento.add(sub);



            // Tabla
            int columnas =
                modelo.getColumnCount();

            PdfPTable tabla =
                new PdfPTable(columnas);

            tabla.setWidthPercentage(100);



            // Encabezados
            Font fuenteHeader =
                FontFactory.getFont(
                    FontFactory.HELVETICA_BOLD,
                    11
                );

            fuenteHeader.setColor(255, 255, 255);

            for(int i = 0; i < columnas; i++) {

                PdfPCell celda =
                    new PdfPCell(
                        new Phrase(
                            modelo.getColumnName(i),
                            fuenteHeader
                        )
                    );

                celda.setBackgroundColor(
                    new java.awt.Color(37, 99, 235)
                );

                celda.setPadding(7);

                celda.setHorizontalAlignment(
                    Element.ALIGN_CENTER
                );

                tabla.addCell(celda);
            }



            // Filas
            Font fuenteFila =
                FontFactory.getFont(
                    FontFactory.HELVETICA,
                    10
                );

            for(
                int f = 0;
                f < modelo.getRowCount();
                f++
            ) {

                java.awt.Color colorFila =
                    f % 2 == 0
                    ? new java.awt.Color(
                        241, 245, 249
                      )
                    : java.awt.Color.WHITE;

                for(
                    int c = 0;
                    c < columnas;
                    c++
                ) {

                    Object val =
                        modelo.getValueAt(f, c);

                    PdfPCell celda =
                        new PdfPCell(
                            new Phrase(
                                val != null
                                ? val.toString()
                                : "",
                                fuenteFila
                            )
                        );

                    celda.setBackgroundColor(
                        colorFila
                    );

                    celda.setPadding(6);

                    tabla.addCell(celda);
                }
            }

            documento.add(tabla);



            // Resumen al final
            Font fuenteResumen =
                FontFactory.getFont(
                    FontFactory.HELVETICA_BOLD,
                    11
                );

            Paragraph pResumen =
                new Paragraph(
                    "\n" + resumen,
                    fuenteResumen
                );

            pResumen.setAlignment(
                Element.ALIGN_RIGHT
            );

            documento.add(pResumen);

            documento.close();

            ErrorControlador.mostrarExito(
                "PDF exportado: " + nombre
            );

        } catch (Exception e) {

            ErrorControlador.mostrarError(
                "Error al exportar PDF.\n"
                + "Asegurate de tener la "
                + "libreria iText/OpenPDF "
                + "en el classpath.",
                e
            );
        }
    }
}