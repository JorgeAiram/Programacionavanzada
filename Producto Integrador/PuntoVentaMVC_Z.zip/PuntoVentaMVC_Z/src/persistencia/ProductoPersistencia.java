package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.table.DefaultTableModel;

import modelo.Producto;
import util.ErrorControlador;

public class ProductoPersistencia {

    public boolean guardarProducto(
        Producto producto
    ) {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "INSERT INTO productos("
                + "nombre,"
                + "precio,"
                + "stock,"
                + "categoria,"
                + "stock_minimo,"
                + "imagen_path"
                + ") "
                + "VALUES(?,?,?,?,?,?)";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            statement.setString(
                1,
                producto.getNombre()
            );

            statement.setDouble(
                2,
                producto.getPrecio()
            );

            statement.setInt(
                3,
                producto.getStock()
            );

            statement.setString(
                4,
                producto.getCategoria()
            );

            statement.setInt(
                5,
                producto.getStockMinimo()
            );

            statement.setString(
                6,
                producto.getImagenPath()
            );

            statement.executeUpdate();

            conexion.close();

            return true;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al guardar producto",
                e
            );

            return false;
        }
    }

    public DefaultTableModel listarProductos() {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "SELECT * FROM productos";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            ResultSet resultado =
                statement.executeQuery();

            String[] columnas = {
                "ID",
                "Nombre",
                "Precio",
                "Stock",
                "Categoría",
                "Stock Mín.",
                "Imagen"
            };

            DefaultTableModel modelo =
                new DefaultTableModel(
                    null,
                    columnas
                );

            while(resultado.next()) {

                Object[] fila = {
                    resultado.getInt("id"),
                    resultado.getString("nombre"),
                    resultado.getDouble("precio"),
                    resultado.getInt("stock"),
                    resultado.getString("categoria"),
                    resultado.getInt("stock_minimo"),
                    resultado.getString("imagen_path")
                };

                modelo.addRow(fila);
            }

            conexion.close();

            return modelo;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al listar productos",
                e
            );

            return null;
        }
    }

    public boolean eliminarProducto(
        int id
    ) throws Exception {

        Connection conexion =
            Conexion.conectar();

        String sql =
            "DELETE FROM productos "
            + "WHERE id = ?";

        PreparedStatement statement =
            conexion.prepareStatement(sql);

        statement.setInt(1, id);

        statement.executeUpdate();

        conexion.close();

        return true;
    }

    public boolean editarProducto(
        Producto producto,
        int id
    ) {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "UPDATE productos SET "
                + "nombre = ?, "
                + "precio = ?, "
                + "stock = ?, "
                + "categoria = ?, "
                + "stock_minimo = ?, "
                + "imagen_path = ? "
                + "WHERE id = ?";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            statement.setString(
                1,
                producto.getNombre()
            );

            statement.setDouble(
                2,
                producto.getPrecio()
            );

            statement.setInt(
                3,
                producto.getStock()
            );

            statement.setString(
                4,
                producto.getCategoria()
            );

            statement.setInt(
                5,
                producto.getStockMinimo()
            );

            statement.setString(
                6,
                producto.getImagenPath()
            );

            statement.setInt(
                7,
                id
            );

            statement.executeUpdate();

            conexion.close();

            return true;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al editar producto id="
                + id,
                e
            );

            return false;
        }
    }

    public DefaultTableModel buscarProductos(
        String texto
    ) {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "SELECT * FROM productos "
                + "WHERE nombre LIKE ? "
                + "OR categoria LIKE ?";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            statement.setString(
                1,
                "%" + texto + "%"
            );

            statement.setString(
                2,
                "%" + texto + "%"
            );

            ResultSet resultado =
                statement.executeQuery();

            String[] columnas = {
                "ID",
                "Nombre",
                "Precio",
                "Stock",
                "Categoría",
                "Stock Mín.",
                "Imagen"
            };

            DefaultTableModel modelo =
                new DefaultTableModel(
                    null,
                    columnas
                );

            while(resultado.next()) {

                Object[] fila = {
                    resultado.getInt("id"),
                    resultado.getString("nombre"),
                    resultado.getDouble("precio"),
                    resultado.getInt("stock"),
                    resultado.getString("categoria"),
                    resultado.getInt("stock_minimo"),
                    resultado.getString("imagen_path")
                };

                modelo.addRow(fila);
            }

            conexion.close();

            return modelo;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al buscar productos",
                e
            );

            return null;
        }
    }

    public Producto obtenerProductoPorId(
        int id
    ) {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "SELECT * FROM productos "
                + "WHERE id = ?";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            statement.setInt(1, id);

            ResultSet resultado =
                statement.executeQuery();

            if(resultado.next()) {

                Producto producto =
                    new Producto();

                producto.setId(
                    resultado.getInt("id")
                );

                producto.setNombre(
                    resultado.getString("nombre")
                );

                producto.setPrecio(
                    resultado.getDouble("precio")
                );

                producto.setStock(
                    resultado.getInt("stock")
                );

                producto.setCategoria(
                    resultado.getString("categoria")
                );

                producto.setStockMinimo(
                    resultado.getInt("stock_minimo")
                );

                producto.setImagenPath(
                    resultado.getString("imagen_path")
                );

                conexion.close();

                return producto;
            }

            conexion.close();

            return null;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al obtener producto id="
                + id,
                e
            );

            return null;
        }
    }

    public boolean descontarStock(
        int idProducto,
        int cantidad
    ) {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "UPDATE productos SET "
                + "stock = stock - ? "
                + "WHERE id = ?";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            statement.setInt(1, cantidad);

            statement.setInt(2, idProducto);

            statement.executeUpdate();

            conexion.close();

            return true;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al descontar stock id="
                + idProducto,
                e
            );

            return false;
        }
    }

    public boolean agregarStock(
        int idProducto,
        int cantidad
    ) {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "UPDATE productos SET "
                + "stock = stock + ? "
                + "WHERE id = ?";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            statement.setInt(1, cantidad);

            statement.setInt(2, idProducto);

            statement.executeUpdate();

            conexion.close();

            return true;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al agregar stock id="
                + idProducto,
                e
            );

            return false;
        }
    }

    public boolean actualizarPrecio(
        int idProducto,
        double nuevoPrecio
    ) {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "UPDATE productos SET "
                + "precio = ? "
                + "WHERE id = ?";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            statement.setDouble(1, nuevoPrecio);

            statement.setInt(2, idProducto);

            statement.executeUpdate();

            conexion.close();

            return true;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al actualizar precio id="
                + idProducto,
                e
            );

            return false;
        }
    }

    public DefaultTableModel listarBajoStock() {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "SELECT * FROM productos "
                + "WHERE stock <= stock_minimo";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            ResultSet resultado =
                statement.executeQuery();

            String[] columnas = {
                "ID",
                "Nombre",
                "Stock Actual",
                "Stock Mínimo",
                "Categoría"
            };

            DefaultTableModel modelo =
                new DefaultTableModel(
                    null,
                    columnas
                );

            while(resultado.next()) {

                Object[] fila = {
                    resultado.getInt("id"),
                    resultado.getString("nombre"),
                    resultado.getInt("stock"),
                    resultado.getInt("stock_minimo"),
                    resultado.getString("categoria")
                };

                modelo.addRow(fila);
            }

            conexion.close();

            return modelo;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al listar bajo stock",
                e
            );

            return null;
        }
    }

    public int totalProductos() {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "SELECT COUNT(*) "
                + "AS total "
                + "FROM productos";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            ResultSet resultado =
                statement.executeQuery();

            if(resultado.next()) {

                int total =
                    resultado.getInt("total");

                conexion.close();

                return total;
            }

            conexion.close();

            return 0;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al contar productos",
                e
            );

            return 0;
        }
    }

    public int totalProductosBajoStock() {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "SELECT COUNT(*) AS total "
                + "FROM productos "
                + "WHERE stock <= stock_minimo";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            ResultSet resultado =
                statement.executeQuery();

            if(resultado.next()) {

                int total =
                    resultado.getInt("total");

                conexion.close();

                return total;
            }

            conexion.close();

            return 0;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al contar bajo stock",
                e
            );

            return 0;
        }
    }
}