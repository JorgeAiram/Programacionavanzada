package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import modelo.Usuario;

public class UsuarioPersistencia {

    public Usuario iniciarSesion(
        String usuario,
        String password
    ) {

        String sql =
            "SELECT * FROM usuarios "
            + "WHERE usuario = ? "
            + "AND password = ?";

        try {

            Connection conexion =
                Conexion.conectar();

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            statement.setString(1, usuario);

            statement.setString(2, password);

            ResultSet resultado =
                statement.executeQuery();

            if(resultado.next()) {

                Usuario usuarioSistema =
                    new Usuario();

                usuarioSistema.setId(
                    resultado.getInt("id")
                );

                usuarioSistema.setNombre(
                    resultado.getString("nombre")
                );

                usuarioSistema.setUsuario(
                    resultado.getString("usuario")
                );

                usuarioSistema.setPassword(
                    resultado.getString("password")
                );

                usuarioSistema.setRol(
                    resultado.getString("rol")
                );

                return usuarioSistema;
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return null;
    }
}