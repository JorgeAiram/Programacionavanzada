package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JOptionPane;

import modelo.Producto;
import persistencia.ProductoPersistencia;
import util.ErrorControlador;
import vista.ProductosVista;

public class ProductoControlador
    implements ActionListener {

    private ProductosVista vista;

    private ProductoPersistencia persistencia;

    public ProductoControlador(
        ProductosVista vista
    ) {

        this.vista = vista;

        persistencia =
            new ProductoPersistencia();

        this.vista
            .getBtnGuardar()
            .addActionListener(this);

        this.vista
            .getBtnEliminar()
            .addActionListener(this);

        this.vista
            .getBtnEditar()
            .addActionListener(this);

        this.vista
            .getTablaProductos()
            .addMouseListener(

                new MouseAdapter() {

                    @Override
                    public void mouseClicked(
                        MouseEvent e
                    ) {

                        cargarProductoSeleccionado();
                    }
                }
            );

        this.vista
            .getTxtBuscar()
            .addKeyListener(

                new KeyAdapter() {

                    @Override
                    public void keyReleased(
                        KeyEvent e
                    ) {

                        buscarProductos();
                    }
                }
            );

        cargarTabla();
    }

    @Override
    public void actionPerformed(
        ActionEvent e
    ) {

        if(
            e.getSource()
            ==
            vista.getBtnGuardar()
        ) {

            guardarProducto();
        }

        if(
            e.getSource()
            ==
            vista.getBtnEliminar()
        ) {

            eliminarProducto();
        }

        if(
            e.getSource()
            ==
            vista.getBtnEditar()
        ) {

            editarProducto();
        }
    }

    public void guardarProducto() {

        try {

            String nombre =

                vista
                .getTxtNombre()
                .getText();

            double precio =

                Double.parseDouble(

                    vista
                    .getTxtPrecio()
                    .getText()
                );

            int stock =

                Integer.parseInt(

                    vista
                    .getTxtStock()
                    .getText()
                );

            String categoria =

                vista
                .getTxtCategoria()
                .getText();

            Producto producto =
                new Producto();

            producto.setNombre(nombre);

            producto.setPrecio(precio);

            producto.setStock(stock);

            producto.setCategoria(categoria);

            boolean guardado =

                persistencia
                .guardarProducto(producto);

            if(guardado) {

                JOptionPane.showMessageDialog(
                    null,
                    "Producto guardado"
                );

                limpiarCampos();

                cargarTabla();

            } else {

                JOptionPane.showMessageDialog(
                    null,
                    "Error al guardar"
                );
            }

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                null,
                "Datos inválidos"
            );
        }
    }

    public void eliminarProducto() {

        int fila =

            vista
            .getTablaProductos()
            .getSelectedRow();

        if(fila == -1) {

            ErrorControlador.mostrarAdvertencia(
                "Selecciona un producto "
                + "de la tabla"
            );

            return;
        }

        int id =

            Integer.parseInt(

                vista
                .getTablaProductos()
                .getValueAt(fila, 0)
                .toString()
            );

        String nombre =

            vista
            .getTablaProductos()
            .getValueAt(fila, 1)
            .toString();

        if(
            !ErrorControlador.confirmar(
                "¿Eliminar el producto '"
                + nombre + "'?"
            )
        ) {

            return;
        }

        try {

            boolean eliminado =
                persistencia
                .eliminarProducto(id);

            if(eliminado) {

                ErrorControlador.mostrarExito(
                    "Producto eliminado"
                );

                limpiarCampos();

                cargarTabla();
            }

        } catch (Exception ex) {

            String mensaje = ex.getMessage();

            if(
                mensaje != null
                && (
                    mensaje.contains("FK")
                    || mensaje.contains(
                        "FOREIGN KEY"
                    )
                    || mensaje.contains(
                        "REFERENCE"
                    )
                )
            ) {

                ErrorControlador.mostrarAdvertencia(
                    "No se puede eliminar '"
                    + nombre + "'.\n\n"
                    + "Este producto tiene ventas "
                    + "registradas en el historial.\n"
                    + "Para retirarlo del inventario "
                    + "usa el modulo de Almacen\n"
                    + "y ajusta el stock a cero."
                );

            } else {

                ErrorControlador.mostrarError(
                    "Error al eliminar el producto",
                    ex
                );
            }
        }
    }

    public void editarProducto() {

        int fila =

            vista
            .getTablaProductos()
            .getSelectedRow();

        if(fila == -1) {

            JOptionPane.showMessageDialog(
                null,
                "Selecciona un producto"
            );

            return;
        }

        try {

            int id =

                Integer.parseInt(

                    vista
                    .getTablaProductos()
                    .getValueAt(fila, 0)
                    .toString()
                );

            String nombre =

                vista
                .getTxtNombre()
                .getText();

            double precio =

                Double.parseDouble(

                    vista
                    .getTxtPrecio()
                    .getText()
                );

            int stock =

                Integer.parseInt(

                    vista
                    .getTxtStock()
                    .getText()
                );

            String categoria =

                vista
                .getTxtCategoria()
                .getText();

            Producto producto =
                new Producto();

            producto.setNombre(nombre);

            producto.setPrecio(precio);

            producto.setStock(stock);

            producto.setCategoria(categoria);

            boolean editado =

                persistencia
                .editarProducto(
                    producto,
                    id
                );

            if(editado) {

                JOptionPane.showMessageDialog(
                    null,
                    "Producto editado"
                );

                limpiarCampos();

                cargarTabla();

            } else {

                JOptionPane.showMessageDialog(
                    null,
                    "Error al editar"
                );
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                null,
                "Datos inválidos"
            );
        }
    }

    public void buscarProductos() {

        String texto =

            vista
            .getTxtBuscar()
            .getText();

        vista
            .getTablaProductos()
            .setModel(

                persistencia
                .buscarProductos(texto)
            );
    }

    public void cargarTabla() {

        vista
            .getTablaProductos()
            .setModel(

                persistencia
                .listarProductos()
            );
    }

    public void limpiarCampos() {

        vista
            .getTxtNombre()
            .setText("");

        vista
            .getTxtPrecio()
            .setText("");

        vista
            .getTxtStock()
            .setText("");

        vista
            .getTxtCategoria()
            .setText("");
    }

    public void cargarProductoSeleccionado() {

        int fila =

            vista
            .getTablaProductos()
            .getSelectedRow();

        if(fila != -1) {

            String nombre =

                vista
                .getTablaProductos()
                .getValueAt(fila, 1)
                .toString();

            String precio =

                vista
                .getTablaProductos()
                .getValueAt(fila, 2)
                .toString();

            String stock =

                vista
                .getTablaProductos()
                .getValueAt(fila, 3)
                .toString();

            String categoria =

                vista
                .getTablaProductos()
                .getValueAt(fila, 4)
                .toString();

            vista
                .getTxtNombre()
                .setText(nombre);

            vista
                .getTxtPrecio()
                .setText(precio);

            vista
                .getTxtStock()
                .setText(stock);

            vista
                .getTxtCategoria()
                .setText(categoria);
        }
    }
}