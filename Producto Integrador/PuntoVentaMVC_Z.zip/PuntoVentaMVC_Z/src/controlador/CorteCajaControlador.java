package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import persistencia.CorteCajaPersistencia;
import util.ErrorControlador;
import vista.CorteCajaVista;

public class CorteCajaControlador
    implements ActionListener {

    private CorteCajaVista vista;

    private CorteCajaPersistencia persistencia;

    public CorteCajaControlador(
        CorteCajaVista vista
    ) {

        this.vista = vista;

        persistencia =
            new CorteCajaPersistencia();

        cargarTabla();

        actualizarEstado();

        this.vista
            .getBtnAbrirCorte()
            .addActionListener(this);

        this.vista
            .getBtnCerrarCorte()
            .addActionListener(this);
    }

    @Override
    public void actionPerformed(
        ActionEvent e
    ) {

        if(
            e.getSource()
            ==
            vista.getBtnAbrirCorte()
        ) {

            abrirCorte();
        }

        if(
            e.getSource()
            ==
            vista.getBtnCerrarCorte()
        ) {

            cerrarCorte();
        }
    }

    public void abrirCorte() {

        if(persistencia.hayCorteAbierto()) {

            ErrorControlador.mostrarAdvertencia(
                "Ya hay un corte abierto.\n"
                + "Debes cerrarlo antes de "
                + "abrir uno nuevo."
            );

            return;
        }

        try {

            double fondo =
                Double.parseDouble(
                    vista
                    .getTxtFondoInicial()
                    .getText()
                    .trim()
                );

            if(fondo < 0) {

                ErrorControlador.mostrarAdvertencia(
                    "El fondo inicial no puede "
                    + "ser negativo"
                );

                return;
            }

            int id =
                persistencia.abrirCorte(fondo);

            if(id != -1) {

                ErrorControlador.mostrarExito(
                    "Corte abierto correctamente.\n"
                    + "Fondo inicial: $"
                    + String.format("%.2f", fondo)
                );

                cargarTabla();

                actualizarEstado();

            } else {

                ErrorControlador.mostrarError(
                    "Error al abrir el corte",
                    null
                );
            }

        } catch (NumberFormatException ex) {

            ErrorControlador.mostrarAdvertencia(
                "Ingresa un fondo inicial valido"
            );
        }
    }

    public void cerrarCorte() {

        if(!persistencia.hayCorteAbierto()) {

            ErrorControlador.mostrarAdvertencia(
                "No hay ningun corte abierto."
            );

            return;
        }

        try {

            double efectivo =
                Double.parseDouble(
                    vista
                    .getTxtEfectivoContado()
                    .getText()
                    .trim()
                );

            String observaciones =
                vista
                .getTxtObservaciones()
                .getText()
                .trim();

            if(
                !ErrorControlador.confirmar(
                    "¿Confirmar cierre de caja?\n"
                    + "Efectivo contado: $"
                    + String.format("%.2f", efectivo)
                )
            ) {

                return;
            }

            int idCorte =
                persistencia
                .obtenerIdCorteAbierto();

            boolean ok =
                persistencia.cerrarCorte(
                    idCorte,
                    efectivo,
                    observaciones
                );

            if(ok) {

                cargarTabla();

                actualizarEstado();

                mostrarResumenCierre(
                    idCorte, efectivo
                );

                vista
                    .getTxtObservaciones()
                    .setText("");

                vista
                    .getTxtEfectivoContado()
                    .setText("0.00");

            } else {

                ErrorControlador.mostrarError(
                    "Error al cerrar el corte",
                    null
                );
            }

        } catch (NumberFormatException ex) {

            ErrorControlador.mostrarAdvertencia(
                "Ingresa el efectivo contado"
            );
        }
    }

    public void actualizarEstado() {

        boolean abierto =
            persistencia.hayCorteAbierto();

        if(abierto) {

            vista
                .getLblEstado()
                .setText(
                    "CORTE ABIERTO"
                );

            vista
                .getLblEstado()
                .setForeground(
                    new java.awt.Color(22, 163, 74)
                );

            Object[] resumen =
                persistencia
                .obtenerResumenCorteAbierto();

            if(resumen != null) {

                double fondo =
                    (double) resumen[1];

                double ventas =
                    (double) resumen[4];

                double totalSistema =
                    fondo + ventas;

                vista
                    .getLblFondoInicial()
                    .setText(
                        String.format(
                            "$%.2f", fondo
                        )
                    );

                vista
                    .getLblVentasHoy()
                    .setText(
                        String.format(
                            "$%.2f", ventas
                        )
                    );

                vista
                    .getLblTotalSistema()
                    .setText(
                        String.format(
                            "$%.2f", totalSistema
                        )
                    );

                vista
                    .getLblDiferencia()
                    .setText("Pendiente");
            }

        } else {

            vista
                .getLblEstado()
                .setText("SIN CORTE ABIERTO");

            vista
                .getLblEstado()
                .setForeground(
                    new java.awt.Color(234, 88, 12)
                );

            vista
                .getLblFondoInicial()
                .setText("$0.00");

            vista
                .getLblVentasHoy()
                .setText("$0.00");

            vista
                .getLblTotalSistema()
                .setText("$0.00");

            vista
                .getLblDiferencia()
                .setText("$0.00");
        }
    }

    public void mostrarResumenCierre(
        int idCorte,
        double efectivo
    ) {

        Object[] resumen =
            persistencia
            .obtenerResumenCorteAbierto();

        // Como ya se cerró, leemos de la tabla
        javax.swing.table.DefaultTableModel modelo =
            persistencia.listarCortes();

        if(modelo != null && modelo.getRowCount() > 0) {

            double ventas =
                Double.parseDouble(
                    modelo.getValueAt(0, 5)
                    .toString()
                );

            double totalSistema =
                Double.parseDouble(
                    modelo.getValueAt(0, 6)
                    .toString()
                );

            double diferencia =
                Double.parseDouble(
                    modelo.getValueAt(0, 8)
                    .toString()
                );

            String msg =
                "=== RESUMEN DE CIERRE ===\n\n"
                + "Ventas del dia:   $"
                + String.format("%.2f", ventas)
                + "\nTotal sistema:    $"
                + String.format("%.2f", totalSistema)
                + "\nEfectivo contado: $"
                + String.format("%.2f", efectivo)
                + "\n\nDiferencia: $"
                + String.format("%.2f", diferencia);

            if(diferencia > 0) {

                msg += "\n(Sobrante)";

            } else if(diferencia < 0) {

                msg += "\n(Faltante)";

            } else {

                msg += "\n(Cuadrado exacto)";
            }

            ErrorControlador.mostrarExito(msg);
        }
    }

    public void cargarTabla() {

        vista
            .getTablaCortes()
            .setModel(
                persistencia.listarCortes()
            );
    }
}