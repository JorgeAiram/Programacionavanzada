package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;

import javax.swing.table.DefaultTableModel;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import persistencia.PDFReporteVentas;
import persistencia.VentaPersistencia;
import util.ErrorControlador;
import vista.ReportesVista;


public class ReportesControlador
    implements ActionListener {

    private ReportesVista vista;

    private VentaPersistencia persistencia;

    private DefaultTableModel modeloActual;

    public ReportesControlador(
        ReportesVista vista
    ) {

        this.vista = vista;

        persistencia =
            new VentaPersistencia();

        cargarTodas();

        this.vista
            .getBtnBuscar()
            .addActionListener(this);

        this.vista
            .getBtnTodas()
            .addActionListener(this);

        this.vista
            .getBtnExcel()
            .addActionListener(this);

        this.vista
            .getBtnPdf()
            .addActionListener(this);
    }

    @Override
    public void actionPerformed(
        ActionEvent e
    ) {

        if(
            e.getSource()
            ==
            vista.getBtnBuscar()
        ) {

            buscarPorFecha();
        }

        if(
            e.getSource()
            ==
            vista.getBtnTodas()
        ) {

            cargarTodas();
        }

        if(
            e.getSource()
            ==
            vista.getBtnExcel()
        ) {

            exportarExcel();
        }

        if(
            e.getSource()
            ==
            vista.getBtnPdf()
        ) {

            exportarPDF();
        }
    }

    public void cargarTodas() {

        modeloActual =
            persistencia.listarVentas();

        vista
            .getTablaReporte()
            .setModel(modeloActual);

        actualizarResumen();
    }

    public void buscarPorFecha() {

        String inicio =
            vista
            .getTxtFechaInicio()
            .getText()
            .trim();

        String fin =
            vista
            .getTxtFechaFin()
            .getText()
            .trim();

        if(
            inicio.isEmpty()
            || fin.isEmpty()
        ) {

            ErrorControlador.mostrarAdvertencia(
                "Ingresa fechas de inicio y fin\n"
                + "Formato: yyyy-MM-dd"
            );

            return;
        }

        modeloActual =
            persistencia
            .listarVentasPorFecha(
                inicio,
                fin
            );

        vista
            .getTablaReporte()
            .setModel(modeloActual);

        actualizarResumen();
    }

    public void actualizarResumen() {

        if(modeloActual == null) {

            return;
        }

        int filas =
            modeloActual.getRowCount();

        double total = 0;

        for(
            int i = 0;
            i < filas;
            i++
        ) {

            Object val =
                modeloActual.getValueAt(i, 5);

            if(val != null) {

                total +=
                    Double.parseDouble(
                        val.toString()
                    );
            }
        }

        vista
            .getLblResumen()
            .setText(
                String.format(
                    "Resultados: %d ventas  |  "
                    + "Total: $%.2f",
                    filas,
                    total
                )
            );
    }

    public void exportarExcel() {

        if(
            modeloActual == null
            || modeloActual.getRowCount() == 0
        ) {

            ErrorControlador.mostrarAdvertencia(
                "No hay datos para exportar"
            );

            return;
        }

        try {

            Workbook wb =
                new XSSFWorkbook();

            Sheet hoja =
                wb.createSheet("Ventas");

            // Estilo encabezado
            CellStyle estiloHeader =
                wb.createCellStyle();

            Font fuenteHeader =
                wb.createFont();

            fuenteHeader.setBold(true);

            fuenteHeader.setColor(
                IndexedColors.WHITE.getIndex()
            );

            estiloHeader.setFont(fuenteHeader);

            estiloHeader.setFillForegroundColor(
                IndexedColors.DARK_BLUE.getIndex()
            );

            estiloHeader.setFillPattern(
                FillPatternType.SOLID_FOREGROUND
            );

            // Encabezados
            Row headerRow = hoja.createRow(0);

            String[] cols = {
                "ID",
                "Fecha de Venta",
                "Hora",
                "Subtotal",
                "Descuento",
                "Total a Pagar"
            };

            for(
                int c = 0;
                c < cols.length;
                c++
            ) {

                Cell cell =
                    headerRow.createCell(c);

                cell.setCellValue(cols[c]);

                cell.setCellStyle(estiloHeader);

                hoja.setColumnWidth(
                    c,
                    5000
                );
            }

            // Datos
            for(
                int r = 0;
                r < modeloActual.getRowCount();
                r++
            ) {

                Row row =
                    hoja.createRow(r + 1);

                for(
                    int c = 0;
                    c < modeloActual
                        .getColumnCount();
                    c++
                ) {

                    Object val =
                        modeloActual
                        .getValueAt(r, c);

                    Cell cell =
                        row.createCell(c);

                    if(val != null) {

                        cell.setCellValue(
                            val.toString()
                        );
                    }
                }
            }

            String nombre =
                "Reporte_Ventas_"
                + java.time.LocalDate
                  .now()
                  .toString()
                + ".xlsx";

            FileOutputStream fos =
                new FileOutputStream(nombre);

            wb.write(fos);

            fos.close();

            wb.close();

            ErrorControlador.mostrarExito(
                "Excel exportado: " + nombre
            );

        } catch (Exception e) {

            ErrorControlador.mostrarError(
                "Error al exportar Excel.\n"
                + "Asegúrate de tener la librería "
                + "Apache POI en el classpath.",
                e
            );
        }
    }

    public void exportarPDF() {

        if(
            modeloActual == null
            || modeloActual.getRowCount() == 0
        ) {

            ErrorControlador.mostrarAdvertencia(
                "No hay datos para exportar"
            );

            return;
        }

        String resumen =
            vista
            .getLblResumen()
            .getText();

        PDFReporteVentas.exportarPDF(
            modeloActual,
            resumen
        );
    }
}